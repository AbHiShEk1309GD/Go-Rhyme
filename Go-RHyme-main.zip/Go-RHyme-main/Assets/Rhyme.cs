using System;

[Serializable]
public class Rhyme
{
    public string word;
    public int score;
    public int numSyllables;
}


